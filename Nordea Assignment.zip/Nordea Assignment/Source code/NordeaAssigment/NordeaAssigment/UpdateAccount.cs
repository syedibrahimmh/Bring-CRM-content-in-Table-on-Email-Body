﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Crm.Sdk;
using Microsoft.Xrm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Globalization;

namespace NordeaAssigment
{
    public class UpdateAccount : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            ITracingService tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            tracingService.Trace("Update " + "Risk profile questions and rules" + "Plugin Started");
            if (context.InputParameters.Contains("Target"))
            {
                if (context.Depth == 1 && context.MessageName == "Update")
                {
                    // throw new InvalidPluginExecutionException(context.UserId.ToString());

                    IList<string> RiskQuestions = new List<string>
                                                 { "Yearly Average Turnover [m€]","Why are you trading Financial Instruments?","Suitable investment                                objectives","Investment horizon","Comment","Experience in Financial Instruments" };

                    #region Entity PreImage Values
                    Entity Pre_Account = (Entity)context.PreEntityImages["PreImage"];

                     var Pre_YearlyTurnover = Pre_Account.Attributes.Contains("nor_yearlyaverageturnoverm") ?
                        Pre_Account.Attributes["nor_yearlyaverageturnoverm"] : null;

                    if (Pre_YearlyTurnover == null)
                    {
                        Pre_YearlyTurnover = string.Empty;
                    }

                    string Pre_WhyTrading = Pre_Account.Attributes.Contains("nor_whyareyoutradingfinancialinstruments") ?
                                           (string)Pre_Account.FormattedValues["nor_whyareyoutradingfinancialinstruments"] : string.Empty;

                    string Pre_SuitableObjects = Pre_Account.Attributes.Contains("nor_suitableinvestmentobjectives") ?
                                                                  (string)Pre_Account.FormattedValues["nor_suitableinvestmentobjectives"] : string.Empty;
                 
                    
                    //throw new InvalidPluginExecutionException(Pre_SuitableObjects);
                    string Pre_InvestmentHorizon = Pre_Account.Attributes.Contains("nor_investmenthorizon") ? 
                                                  (string) Pre_Account.FormattedValues["nor_investmenthorizon"] : string.Empty;

                    string Pre_comment = Pre_Account.Attributes.Contains("nor_comment") ? (string)Pre_Account.Attributes["nor_comment"] : string.Empty;

                    string Pre_Experience = Pre_Account.Attributes.Contains("nor_experienceinfinancialinstruments") ?
                                            (string)Pre_Account.FormattedValues["nor_experienceinfinancialinstruments"] : string.Empty;

                    IList<object> PreImageList = new List<object> { Pre_YearlyTurnover, Pre_WhyTrading ,
                                                                    Pre_InvestmentHorizon,Pre_comment,Pre_Experience};

                    #endregion

                    #region Entity PostImage Values
                    Entity Post_Account = (Entity)context.PostEntityImages["PostImage"];
                    var AccountName = Post_Account.Attributes.Contains("name") ? Post_Account.Attributes["name"] : null;

                    EntityReference Owner = (EntityReference)Post_Account.Attributes["ownerid"];
                    EntityReference ModifiedBy = (EntityReference)Post_Account.Attributes["modifiedby"];
                    DateTime modifiedOn = Post_Account.Attributes.Contains("modifiedon") ?
                         (DateTime)Post_Account.Attributes["modifiedon"] : DateTime.MinValue;
                    tracingService.Trace("Owner of the Record:" + Owner.Name + "/Owner ID:" + Owner.Id);


                    var Post_YearlyTurnover = Post_Account.Attributes.Contains("nor_yearlyaverageturnoverm") ?
                        Post_Account.Attributes["nor_yearlyaverageturnoverm"] : null;

                    if (Post_YearlyTurnover == null)
                    {
                        Post_YearlyTurnover = string.Empty;
                    }

                    string Post_WhyTrading = Post_Account.Attributes.Contains("nor_whyareyoutradingfinancialinstruments") ?
                                             (string)Post_Account.FormattedValues["nor_whyareyoutradingfinancialinstruments"] : string.Empty;

                    string Post_SuitableObjects = Post_Account.Attributes.Contains("nor_suitableinvestmentobjectives") ?
                                                  (string)Post_Account.FormattedValues["nor_suitableinvestmentobjectives"] : string.Empty;


                    string Post_InvestmentHorizon = Post_Account.Attributes.Contains("nor_investmenthorizon") ?
                                                    (string)Post_Account.FormattedValues["nor_investmenthorizon"] : string.Empty;

                    string Post_comment = Post_Account.Attributes.Contains("nor_comment") ? (string)Post_Account.Attributes["nor_comment"] : string.Empty;

                    string Post_Experience = Post_Account.Attributes.Contains("nor_experienceinfinancialinstruments") ?
                                             (string)Post_Account.FormattedValues["nor_experienceinfinancialinstruments"] : string.Empty;

                    IList<object> PostImageList = new List<object> { Post_YearlyTurnover, Post_WhyTrading ,
                                                                    Post_InvestmentHorizon,Post_comment,Post_Experience};
                    #endregion

                    #region Create Email and send to Owner of the Record

                    Guid userId = context.UserId;
                    string subject = string.Empty;
                    string description = string.Empty;
                    Guid templateId = Guid.Empty;

                    Entity User = service.Retrieve("systemuser", Owner.Id, new ColumnSet("fullname"));




                    string thString = @"style = ""border:1px solid black;text-align:left;background-color:#00CED1;padding:5px;border-spacing:15px""";
                    string tdString = @"style = ""border:lpx solid black;padding:5px""";
                    StringBuilder tablemtmlBuilder = new StringBuilder(@"<table style=""border:2px solid black;border-collapse:collapse"">");

                    tablemtmlBuilder.Append("<tr>");
                    tablemtmlBuilder.AppendFormat("<th {0}>{1}</th>", thString, "Risk Questions");
                    tablemtmlBuilder.AppendFormat("<th {0}>{1}</th>", thString, "Old Value");
                    tablemtmlBuilder.AppendFormat("<th {0}>{1}</th>", thString, "Modified Value");
                    tablemtmlBuilder.Append("</tr>");
                    tablemtmlBuilder.Append("<tr>");
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, RiskQuestions[0]);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Pre_YearlyTurnover);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Post_YearlyTurnover);
                    tablemtmlBuilder.Append("</tr>");
                    tablemtmlBuilder.Append("<tr>");
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, RiskQuestions[1]);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Pre_WhyTrading);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Post_WhyTrading);
                    tablemtmlBuilder.Append("</tr>");
                    tablemtmlBuilder.Append("<tr>");
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, RiskQuestions[2]);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Pre_SuitableObjects);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Post_SuitableObjects);
                    tablemtmlBuilder.Append("</tr>");
                    tablemtmlBuilder.Append("<tr>");
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, RiskQuestions[3]);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Pre_InvestmentHorizon);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Post_InvestmentHorizon);
                    tablemtmlBuilder.Append("</tr>");
                    tablemtmlBuilder.Append("<tr>");
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, RiskQuestions[4]);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Pre_comment);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Post_comment);
                    tablemtmlBuilder.Append("</tr>");
                    tablemtmlBuilder.Append("<tr>");
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, RiskQuestions[5]);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Pre_Experience);
                    tablemtmlBuilder.AppendFormat("<td {0}>{1}</td>", thString, Post_Experience);
                    tablemtmlBuilder.Append("</tr>");


                    tablemtmlBuilder.Append("</table>");
                    string tableHTML = tablemtmlBuilder.ToString();


                    subject = "Risk profile questions modified for the account " + AccountName ;
                    string BodyText = "Dear " + Owner.Name + "<br><br>" +
                                      "Your owned account" +"<b> "+ AccountName+" </b>" + "has been modified by " + "<b> " + ModifiedBy.Name + " </b> " + ", On " + "" + modifiedOn + "<br>";
                    string note =     "Note: This is sytem generated email, don not reply to this id.";

                    string AuditTable = tableHTML;

                    string emailBody = BodyText +"<br>"+ AuditTable + "<br>" + note;

                    Entity fromParty = new Entity("activityparty");
                    fromParty["partyid"] = new EntityReference("systemuser", userId);
                    Entity toParty = new Entity("activityparty");
                    toParty["partyid"] = new EntityReference("systemuser", Owner.Id);

                    tracingService.Trace("Creating new email... ");
                    Entity Email = new Entity("email");
                    Email.Attributes["from"] = new Entity[] { fromParty };
                    Email.Attributes["to"] = new Entity[] { toParty };
                    Email.Attributes["subject"] = subject;
                    Email.Attributes["regardingobjectid"] = new EntityReference("account", Post_Account.Id);
                    Email.Attributes["description"] = emailBody;
                    Email.Attributes["ownerid"] = new EntityReference("systemuser", userId);
                    Guid emailguid = service.Create(Email);
                    tracingService.Trace("Email created... " + emailguid.ToString());


                    //Send Email
                    SendEmailRequest sendEmail = new SendEmailRequest();
                    sendEmail.EmailId = emailguid;
                    sendEmail.IssueSend = true;
                    sendEmail.TrackingToken = "";
                    SendEmailResponse response = (SendEmailResponse)service.Execute(sendEmail);
                    tracingService.Trace("Email sent successfully to Owner of the record" + Environment.NewLine);
                    #endregion


                }

            }





        }
    }
}
