///====================================================================
/// Description : Check Risk Answers got changed and show alert
/// Created By  : Syed
/// Event       : OnSave
/// Created On  : 07/01/2019
///==================================================================== 
function isDirty(executionContext) {
    var formContext = executionContext.getFormContext(); // get formContext
    var formType = Xrm.Page.ui.getFormType();

    var field1 = formContext.getAttribute("nor_copyanswersfrom").getIsDirty();
    var field2 = formContext.getAttribute("nor_yearlyaverageturnoverm").getIsDirty();
    var field3 = formContext.getAttribute("nor_whyareyoutradingfinancialinstruments").getIsDirty();
    var field4 = formContext.getAttribute("nor_suitableinvestmentobjectives").getIsDirty();
    var field5 = formContext.getAttribute("nor_investmenthorizon").getIsDirty();
    var field6 = formContext.getAttribute("nor_comment").getIsDirty();
    var field7 = formContext.getAttribute("nor_experienceinfinancialinstruments").getIsDirty();

    if (((field1 || field2 || field3 || field4 || field5 || field6 || field7) == true) && (formType != 1)) {
        //alert("Risk profile answers got modified. A system notification has sent to the user");
        var alertStrings = { confirmButtonLabel: "Ok", text: "Risk profile answers got modified. A system notification has sent to the owning user" };
        var alertOptions = { height: 150, width: 340 };
        Xrm.Navigation.openAlertDialog(alertStrings, alertOptions).then(
            function success(result) {
                console.log("Alert dialog closed");
            },
            function (error) {
                console.log(error.message);
            }
        );

    }
}

///====================================================================
/// Description : Reset Risk Answers
/// Created By  : Syed
/// Event       : OnButtonClick
/// Created On  : 07/01/2019
///==================================================================== 

function resetAnswers(executionContext) {

    var formContext = executionContext.getFormContext(); // get formContext
    var userSettings = Xrm.Utility.getGlobalContext().userSettings; // userSettings is an object with user information.
    var current_User_Id = userSettings.userId;
    var current_User_Name = userSettings.userName;
   // alert(current_User_Name);

    var confirmStrings = { text: "Note: If you reset Risk profile answers, changes will be notified to the owner.", title: "Are you sure to reset Answers?" };
    var confirmOptions = { height: 200, width: 450 };
    Xrm.Navigation.openConfirmDialog(confirmStrings, confirmOptions).then(
    function (success) {
        if (success.confirmed) {
            formContext.getAttribute("nor_copyanswersfrom").setValue(null);
            formContext.getAttribute("nor_yearlyaverageturnoverm").setValue(null);
            formContext.getAttribute("nor_whyareyoutradingfinancialinstruments").setValue(null);
            formContext.getAttribute("nor_suitableinvestmentobjectives").setValue(null);
            formContext.getAttribute("nor_investmenthorizon").setValue(null);
            formContext.getAttribute("nor_comment").setValue(null);
            formContext.getAttribute("nor_experienceinfinancialinstruments").setValue(null);
            console.log("Dialog closed using OK button.");
            setCommentCompulsary();//Call hide comment function
        }
        else
            console.log("Dialog closed using Cancel button or X.");
    });
   
}


///====================================================================
/// Description : Copy Answer from other customers
/// Created By  : Syed
/// Event       : onChange - Other Cusomter(lookup)
/// Created On  : 07/01/2019
///==================================================================== 

function copyAnswers(executionContext) {
    debugger;

    if (executionContext != null) {
        var formContext = executionContext.getFormContext();
        var recordId = formContext.data.entity.getId();
        var lookupItem = new Array();
        lookupItem = Xrm.Page.getAttribute("nor_copyanswersfrom") ? Xrm.Page.getAttribute("nor_copyanswersfrom").getValue() : null;
        if (lookupItem != null) {
            var customerId = lookupItem[0].id;
            var cusomerName = lookupItem[0].name;
            var entityType = lookupItem[0].entityType;
            customerId = customerId.slice(1, -1);

            // Start --Retrieve values from the selected customer---
            Xrm.WebApi.retrieveRecord("account", customerId, "?$select=name,nor_yearlyaverageturnoverm,nor_whyareyoutradingfinancialinstruments,nor_suitableinvestmentobjectives,nor_investmenthorizon,nor_comment,nor_experienceinfinancialinstruments").then(
            function success(result) {
                formContext.getAttribute("nor_yearlyaverageturnoverm").setValue(result.nor_yearlyaverageturnoverm);
                formContext.getAttribute("nor_whyareyoutradingfinancialinstruments").setValue(result.nor_whyareyoutradingfinancialinstruments);
                formContext.getAttribute("nor_suitableinvestmentobjectives").setValue(result.nor_suitableinvestmentobjectives);
                formContext.getAttribute("nor_investmenthorizon").setValue(result.nor_investmenthorizon);
                formContext.getAttribute("nor_comment").setValue(result.nor_comment);
                formContext.getAttribute("nor_experienceinfinancialinstruments").setValue(result.nor_experienceinfinancialinstruments);
            },
            function (error) {
                console.log(error.message);

            }

            );


        }
    }
}
///====================================================================
/// Description : Set Comment field Compulsary & Visible
/// Created By  : Syed
/// Event       : onChange - Other Cusomter(lookup)
/// Created On  : 07/01/2019
///==================================================================== 
function setCommentCompulsary(executionContext) {
    debugger;
         
    
       // var formContext = executionContext.getFormContext();
    var inverstHorizon = Xrm.Page.getAttribute("nor_investmenthorizon").getValue();
       
       
        Xrm.Page.getAttribute("nor_comment").setRequiredLevel("none");
        Xrm.Page.getControl("nor_comment").setVisible(false);
        if (inverstHorizon == 3 || inverstHorizon == 4) {
            Xrm.Page.getAttribute("nor_comment").setRequiredLevel("required");
            Xrm.Page.getControl("nor_comment").setVisible(true);
        }

}

